R-OpenMPController
==================

R package to control number of OpenMP threads
